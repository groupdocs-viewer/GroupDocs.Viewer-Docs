﻿using System;
using GroupDocs.Viewer;
using GroupDocs.Viewer.Results;
// ...

using (Viewer viewer = new Viewer("protected.pdf"))
{
    // Get file information.
    FileInfo fileInfo = viewer.GetFileInfo();

    // Display the file type and flag if the file is encrypted.
    Console.WriteLine("File type is: " + fileInfo.FileType);
    Console.WriteLine("File encrypted: " + fileInfo.Encrypted);
}