﻿using GroupDocs.Viewer;
using GroupDocs.Viewer.Options;

namespace DemoApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Instantiate Viewer and pass file name
            using (Viewer viewer = new Viewer("formatting.docx"))
            {
                // Configure view options
                HtmlViewOptions viewOptions =
                    HtmlViewOptions.ForEmbeddedResources("output/page-{0}.html");

                // Render DOCX to HTML
                viewer.View(viewOptions);
            }
        }
    }
}