﻿using GroupDocs.Viewer;
using GroupDocs.Viewer.Options;

// Get the absolute path to the license file
string licensePath = Path.GetFullPath("./GroupDocs.Viewer.lic");

if (File.Exists(licensePath))
{
    // Apply the license
    License license = new License();
    license.SetLicense(licensePath);
}

// Load the DOCX document
using (Viewer viewer = new Viewer("./sample.docx"))
{
    // Configure PNG view options
    PngViewOptions pngOptions =
        new PngViewOptions("render_docx_to_png/output_{0}.png");

    // Render the DOCX document to PNG
    viewer.View(pngOptions);

    Console.WriteLine("Rendering completed successfully.");
    Console.WriteLine(@"Check \bin\Debug\net6.0\render_docx_to_png for the results.");
}