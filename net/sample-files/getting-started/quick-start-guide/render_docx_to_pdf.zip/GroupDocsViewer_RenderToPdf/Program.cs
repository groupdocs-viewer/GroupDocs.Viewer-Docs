﻿using GroupDocs.Viewer;
using GroupDocs.Viewer.Options;

// Get the absolute path to the license file
string licensePath = Path.GetFullPath("./GroupDocs.Viewer.lic");

if (File.Exists(licensePath))
{
    // Apply the license
    License license = new License();
    license.SetLicense(licensePath);
}

// Load the DOCX document
using (Viewer viewer = new Viewer("./sample.docx"))
{
    // Configure PDF view options
    PdfViewOptions pdfOptions =
        new PdfViewOptions("render_docx_to_pdf/output.pdf");

    // Render the DOCX document to PDF
    viewer.View(pdfOptions);

    Console.WriteLine("Rendering completed successfully.");
    Console.WriteLine(@"Check \bin\Debug\net6.0\render_docx_to_pdf for the results.");
}