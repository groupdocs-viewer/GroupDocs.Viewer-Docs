﻿using GroupDocs.Viewer;
using GroupDocs.Viewer.Options;

// Get the absolute path to the license file
string licensePath = Path.GetFullPath("./GroupDocs.Viewer.lic");

if (File.Exists(licensePath))
{
    // Apply the license
    License license = new License();
    license.SetLicense(licensePath);
}

// Load the DOCX document
using (Viewer viewer = new Viewer("./sample.docx"))
{
    // Configure HTML view options
    HtmlViewOptions htmlOptions =
        HtmlViewOptions.ForEmbeddedResources("render_docx_to_html/page_{0}.html");

    // Render the DOCX document to HTML
    viewer.View(htmlOptions);

    Console.WriteLine("Rendering completed successfully.");
    Console.WriteLine(@"Check \bin\Debug\net6.0\render_docx_to_html for the results.");
}