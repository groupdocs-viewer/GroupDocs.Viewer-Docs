package com.mycompany.app;

import com.groupdocs.viewer.Viewer;
import com.groupdocs.viewer.options.HtmlViewOptions;

public class App {
    public static void main(String[] args) throws Exception {
      Viewer viewer = new Viewer("sample.docx");
      HtmlViewOptions viewOptions = HtmlViewOptions.forEmbeddedResources();
      viewer.view(viewOptions);
    }
}
