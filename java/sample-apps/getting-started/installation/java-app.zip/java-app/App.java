import com.groupdocs.viewer.Viewer;
import com.groupdocs.viewer.options.*;

public class App {
    public static void main(String[] args) throws Exception {
        Viewer viewer = new Viewer("formatting.docx");
        viewer.view(HtmlViewOptions.forEmbeddedResources());
        viewer.close();
    }
}
