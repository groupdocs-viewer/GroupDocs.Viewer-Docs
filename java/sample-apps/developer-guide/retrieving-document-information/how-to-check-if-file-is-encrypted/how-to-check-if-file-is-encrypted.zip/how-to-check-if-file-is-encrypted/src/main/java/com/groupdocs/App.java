package com.groupdocs;

import com.groupdocs.viewer.Viewer;
import com.groupdocs.viewer.results.FileInfo;

public class App {
    public static void main(String[] args) throws Exception {
        try (Viewer viewer = new Viewer("protected.pdf")) {
            FileInfo fileInfo = viewer.getFileInfo();

            System.out.println("File type is: " + fileInfo.getFileType());
            System.out.println("File encrypted: " + fileInfo.isEncrypted());
        }
    }
}
