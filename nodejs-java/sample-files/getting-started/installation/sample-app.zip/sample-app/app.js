const gdv = require('@groupdocs/groupdocs.viewer')
   
// Path to the file you want to view
const filePath = 'sample.pdf';

// Initialize viewer
const viewer = new gdv.Viewer(filePath);

// Render the file to HTML
viewer.view(gdv.HtmlViewOptions.forEmbeddedResources());

process.exit(0);