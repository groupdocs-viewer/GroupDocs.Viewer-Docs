# GroupDocs.Viewer for Node.js via Java - Docker Example

This sample application demonstrates how to run GroupDocs.Viewer for Node.js via Java inside a Docker container.

## Project Structure

```
📂 basic-example/
├── 📂 work/                           
│   ├── 📄 sample.pdf                  # Input document to render
│   └── 📄 GroupDocs.Viewer.lic        # The license file (optional)
├── 📄 .dockerignore                   # Files to exclude from Docker build context
├── 📄 Dockerfile                      # Docker container definition
├── 📄 package.json                    # Node.js project file
├── 📄 render-file.js                  # Main application code
└── 📄 README.md                       # App readme
```

## Prerequisites

- Docker installed and running
- Node.js 20+ (for local development, optional)

## Building the Docker Image

To create the Docker image, run the following command in the directory containing the `Dockerfile`:

```bash
docker build -t groupdocs-viewer-sample:latest .
```

## Running the Application

In this example we mount the `work` directory and use it both to pass source files into the container and to store the rendered output.

### Without License (Trial Mode)

If you do not have a license file, you can use the following command that omits the last parameter. GroupDocs.Viewer will work in trial mode.

**PowerShell:**
```powershell
docker run --rm -v "${PWD}/work:/work" -w /work groupdocs-viewer-sample:latest sample.pdf output
```

**Bash:**
```bash
docker run --rm -v "$(pwd)/work:/work" -w /work groupdocs-viewer-sample:latest sample.pdf output
```

### With License File

You can add a license parameter if you have a trial or full license file:

**PowerShell:**
```powershell
docker run --rm -v "${PWD}/work:/work" -w /work groupdocs-viewer-sample:latest sample.pdf output GroupDocs.Viewer.lic
```

**Bash:**
```bash
docker run --rm -v "$(pwd)/work:/work" -w /work groupdocs-viewer-sample:latest sample.pdf output GroupDocs.Viewer.lic
```

### Command Explanation

- `--rm`: Automatically removes the container when it exits
- `-v`: Mounts the host directory to the container directory for file output
- `-w`: Sets the working directory inside container

## App Output

The app renders a PDF file and outputs HTML files in the `work` folder. The output contains rendered pages in HTML format (e.g., `page_1.html`, `page_2.html`, etc.).

## Troubleshooting

### Font Issues

If you encounter missing glyphs or layout differences, install additional fonts by adding this to the Dockerfile:

```dockerfile
RUN apt-get update && apt-get install -y fonts-liberation fonts-dejavu-core && rm -rf /var/lib/apt/lists/*
```

### node-gyp Build Errors

- Ensure `build-essential` and `python3` are installed.
- Rebuild if needed: `npm rebuild`.

### Java Not Found

- Confirm OpenJDK is installed and `JAVA_HOME`/`PATH` are set in the image.

### Permissions or Volume Mounts

- Verify the mounted directories exist and are writable by the container user.

## License

MIT License
