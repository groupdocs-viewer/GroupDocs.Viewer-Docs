import { Viewer, License, HtmlViewOptions } from '@groupdocs/groupdocs.viewer';

// Get the input file, output path, and license paths from the command line arguments
const [inputPath, outputPath, licensePathArg] = process.argv.slice(2);

// Get the license path from the command line arguments or the environment variable
const licensePath = licensePathArg || process.env.GROUPDOCS_LICENSE_PATH;
if (licensePath) {
	const license = new License();
	license.setLicense(licensePath);
}

// Create a new viewer instance
const viewer = new Viewer(inputPath);

// Render the file to HTML
const viewOptions = HtmlViewOptions.forEmbeddedResources(outputPath + '/page_{0}.html');
viewer.view(viewOptions);

// Exit the process
process.exit(0);